// ============================================================
// DownloadForge Pro — core/model_zip_bundler.js
// P4inz Interactive Labs | p4inz
//
// Pure In-Browser 3D Model & Textures ZIP Package Builder
// Bundles 3D models (OBJ, GLB, BINZ), MTL materials, and
// PBR textures into clean, organized, zero-dependency ZIP archives.
// ============================================================

import { Logger } from '../utils/logger.js';
import { createGlbContainer } from './gltf_packager.js';

const log = new Logger('ModelZipBundler');

/**
 * Converts a Wavefront OBJ string into a standard, self-contained binary .glb container.
 * @param {string} objText
 * @param {string} [modelTitle]
 * @returns {Uint8Array|null}
 */
/**
 * Convert an ASCII Wavefront .obj text string into a binary glTF 2.0 (.glb) buffer.
 * Preserves POSITION, NORMAL, TEXCOORD_0, PBR Material, and optional embedded baseColor texture.
 * @param {string} objText
 * @param {string} [modelTitle='Model']
 * @param {object} [options={}]
 * @param {Uint8Array} [options.diffuseTextureBytes]
 * @param {string} [options.diffuseMimeType]
 * @returns {Uint8Array|null}
 */
export function convertObjToGlb(objText, modelTitle = 'Model', options = {}) {
  if (!objText || typeof objText !== 'string') return null;
  const rawPos = [];
  const rawNorm = [];
  const rawUv = [];
  const rawFaces = [];
  const lines = objText.split('\n');

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed || trimmed[0] === '#') continue;
    if (trimmed.startsWith('v ')) {
      const parts = trimmed.split(/\s+/);
      const x = Number(parts[1]), y = Number(parts[2]), z = Number(parts[3]);
      if (Number.isFinite(x) && Number.isFinite(y) && Number.isFinite(z)) {
        rawPos.push(x, y, z);
      }
    } else if (trimmed.startsWith('vn ')) {
      const parts = trimmed.split(/\s+/);
      const nx = Number(parts[1]), ny = Number(parts[2]), nz = Number(parts[3]);
      if (Number.isFinite(nx) && Number.isFinite(ny) && Number.isFinite(nz)) {
        rawNorm.push(nx, ny, nz);
      }
    } else if (trimmed.startsWith('vt ')) {
      const parts = trimmed.split(/\s+/);
      const u = Number(parts[1]), v = Number(parts[2]);
      if (Number.isFinite(u) && Number.isFinite(v)) {
        rawUv.push(u, v);
      }
    } else if (trimmed.startsWith('f ')) {
      const parts = trimmed.split(/\s+/).slice(1);
      if (parts.length < 3) continue;
      const vTotal = rawPos.length / 3;
      const vtTotal = rawUv.length / 2;
      const vnTotal = rawNorm.length / 3;
      const verts = [];
      for (const p of parts) {
        const segs = p.split('/');
        const viRaw = parseInt(segs[0], 10);
        if (isNaN(viRaw)) continue;
        const vi = viRaw > 0 ? viRaw - 1 : vTotal + viRaw;
        const vtiRaw = segs[1] ? parseInt(segs[1], 10) : NaN;
        const vti = !isNaN(vtiRaw) ? (vtiRaw > 0 ? vtiRaw - 1 : vtTotal + vtiRaw) : -1;
        const vniRaw = segs[2] ? parseInt(segs[2], 10) : NaN;
        const vni = !isNaN(vniRaw) ? (vniRaw > 0 ? vniRaw - 1 : vnTotal + vniRaw) : -1;
        if (vi >= 0 && vi < vTotal) {
          verts.push([vi, vti >= 0 && vti < vtTotal ? vti : -1, vni >= 0 && vni < vnTotal ? vni : -1]);
        }
      }
      for (let t = 1; t < verts.length - 1; t++) {
        rawFaces.push(verts[0], verts[t], verts[t + 1]);
      }
    }
  }

  if (rawPos.length < 9 || rawFaces.length < 3) return null;

  const hasNormals = rawNorm.length >= 3 && rawFaces.some(f => f[2] >= 0);
  const hasUvs = rawUv.length >= 2 && rawFaces.some(f => f[1] >= 0);

  const vertMap = new Map();
  const outPos = [];
  const outNorm = [];
  const outUv = [];
  const indices = [];

  for (let i = 0; i < rawFaces.length; i++) {
    const [vi, vti, vni] = rawFaces[i];
    const key = (vti === -1 && vni === -1) ? vi : `${vi}|${vti}|${vni}`;
    let outIdx = vertMap.get(key);
    if (outIdx === undefined) {
      outIdx = outPos.length / 3;
      vertMap.set(key, outIdx);
      outPos.push(rawPos[vi * 3], rawPos[vi * 3 + 1], rawPos[vi * 3 + 2]);
      if (hasNormals) {
        if (vni >= 0) {
          outNorm.push(rawNorm[vni * 3], rawNorm[vni * 3 + 1], rawNorm[vni * 3 + 2]);
        } else {
          outNorm.push(0, 0, 1);
        }
      }
      if (hasUvs) {
        if (vti >= 0) {
          outUv.push(rawUv[vti * 2], 1.0 - rawUv[vti * 2 + 1]);
        } else {
          outUv.push(0, 0);
        }
      }
    }
    indices.push(outIdx);
  }

  const vCount = outPos.length / 3;
  let minX = Infinity, minY = Infinity, minZ = Infinity;
  let maxX = -Infinity, maxY = -Infinity, maxZ = -Infinity;
  for (let i = 0; i < outPos.length; i += 3) {
    const x = outPos[i], y = outPos[i + 1], z = outPos[i + 2];
    if (x < minX) minX = x; if (x > maxX) maxX = x;
    if (y < minY) minY = y; if (y > maxY) maxY = y;
    if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
  }

  const posArray = new Float32Array(outPos);
  const normArray = hasNormals ? new Float32Array(outNorm) : null;
  const uvArray = hasUvs ? new Float32Array(outUv) : null;
  const use32BitIndices = vCount > 65535;
  const idxArray = use32BitIndices ? new Uint32Array(indices) : new Uint16Array(indices);

  const chunks = [];
  const bufferViews = [];
  const accessors = [];
  let cursor = 0;

  const appendBin = (typedOrBytes, target) => {
    const raw = typedOrBytes instanceof Uint8Array
      ? typedOrBytes
      : new Uint8Array(typedOrBytes.buffer, typedOrBytes.byteOffset, typedOrBytes.byteLength);
    const pad = (4 - (raw.byteLength % 4)) % 4;
    const bvIndex = bufferViews.length;
    const bv = { buffer: 0, byteOffset: cursor, byteLength: raw.byteLength };
    if (target) bv.target = target;
    bufferViews.push(bv);
    chunks.push({ bytes: raw, pad });
    cursor += raw.byteLength + pad;
    return bvIndex;
  };

  // 0: Indices
  const idxBv = appendBin(idxArray, 34963);
  accessors.push({
    bufferView: idxBv,
    byteOffset: 0,
    componentType: use32BitIndices ? 5125 : 5123,
    count: indices.length,
    type: 'SCALAR'
  });

  // 1: Positions
  const posBv = appendBin(posArray, 34962);
  const posAcc = accessors.length;
  accessors.push({
    bufferView: posBv,
    byteOffset: 0,
    componentType: 5126,
    count: vCount,
    type: 'VEC3',
    min: [minX, minY, minZ],
    max: [maxX, maxY, maxZ]
  });

  const attributes = { POSITION: posAcc };

  if (normArray) {
    const normBv = appendBin(normArray, 34962);
    const normAcc = accessors.length;
    accessors.push({
      bufferView: normBv,
      byteOffset: 0,
      componentType: 5126,
      count: vCount,
      type: 'VEC3'
    });
    attributes.NORMAL = normAcc;
  }

  if (uvArray) {
    const uvBv = appendBin(uvArray, 34962);
    const uvAcc = accessors.length;
    accessors.push({
      bufferView: uvBv,
      byteOffset: 0,
      componentType: 5126,
      count: vCount,
      type: 'VEC2'
    });
    attributes.TEXCOORD_0 = uvAcc;
  }

  const gltf = {
    asset: { version: '2.0', generator: 'DownloadForge Pro 3D Ripper' },
    scenes: [{ nodes: [0] }],
    nodes: [{ mesh: 0, name: modelTitle }],
    meshes: [{
      primitives: [{
        attributes,
        indices: 0,
        material: 0,
        mode: 4
      }]
    }],
    materials: [{
      name: `${modelTitle}_Material`,
      pbrMetallicRoughness: {
        baseColorFactor: [1.0, 1.0, 1.0, 1.0],
        metallicFactor: 0.1,
        roughnessFactor: 0.65
      }
    }],
    buffers: [{ byteLength: cursor }],
    bufferViews,
    accessors
  };

  if (options.diffuseTextureBytes && options.diffuseTextureBytes.byteLength > 16) {
    const imgBv = appendBin(options.diffuseTextureBytes, 0);
    gltf.buffers[0].byteLength = cursor;
    gltf.images = [{
      bufferView: imgBv,
      mimeType: options.diffuseMimeType || 'image/png'
    }];
    gltf.samplers = [{
      magFilter: 9729,
      minFilter: 9987,
      wrapS: 10497,
      wrapT: 10497
    }];
    gltf.textures = [{ sampler: 0, source: 0 }];
    gltf.materials[0].pbrMetallicRoughness.baseColorTexture = { index: 0 };
  }

  const combinedBin = new Uint8Array(cursor);
  let writePos = 0;
  for (const ch of chunks) {
    combinedBin.set(ch.bytes, writePos);
    writePos += ch.bytes.byteLength + ch.pad;
  }

  return createGlbContainer(gltf, combinedBin);
}

// CRC32 Lookup Table
const crcTable = new Uint32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i;
  for (let k = 0; k < 8; k++) c = ((c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
  crcTable[i] = c;
}

export function computeCrc32(buf) {
  let crc = -1;
  for (let i = 0; i < buf.length; i++) crc = (crc >>> 8) ^ crcTable[(crc ^ buf[i]) & 0xFF];
  return (crc ^ -1) >>> 0;
}

/**
 * Convert a Uint8Array into a data: URI safely in Service Workers without DOM or blob URLs.
 * @param {Uint8Array} bytes
 * @param {string} mimeType
 * @returns {string}
 */
export function uint8ArrayToDataUrl(bytes, mimeType = 'application/zip') {
  if (!bytes) return '';
  let binary = '';
  const len = bytes.byteLength;
  const chunkSize = 0x8000;
  for (let i = 0; i < len; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, Math.min(i + chunkSize, len)));
  }
  return `data:${mimeType};base64,${btoa(binary)}`;
}

/**
 * Build a standard ZIP archive from an array of files.
 * @param {Array<{ name: string, data: Uint8Array|string }>} files
 * @returns {Uint8Array}
 */
export function buildZipArchive(files) {
  const localHeaders = [];
  const centralHeaders = [];
  let offset = 0;
  const enc = new TextEncoder();

  for (const f of files) {
    const nameBytes = enc.encode(f.name);
    const dataBytes = f.data instanceof Uint8Array ? f.data : enc.encode(f.data || '');
    const crc = computeCrc32(dataBytes);
    const size = dataBytes.length;

    // Local file header (30 bytes + name)
    const lh = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(lh.buffer);
    lv.setUint32(0, 0x04034B50, true); // Local header signature
    lv.setUint16(4, 20, true);         // Version needed (2.0)
    lv.setUint16(6, 0x0800, true);     // Flags: UTF-8 filename
    lv.setUint16(8, 0, true);          // Compression: 0 (Store)
    lv.setUint16(10, 0, true);         // Mod time
    lv.setUint16(12, 0, true);         // Mod date
    lv.setUint32(14, crc, true);       // CRC-32
    lv.setUint32(18, size, true);      // Compressed size
    lv.setUint32(22, size, true);      // Uncompressed size
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);         // Extra length
    lh.set(nameBytes, 30);

    localHeaders.push({ header: lh, data: dataBytes, offset });

    // Central directory header (46 bytes + name)
    const ch = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(ch.buffer);
    cv.setUint32(0, 0x02014B50, true); // Central header signature
    cv.setUint16(4, 20, true);         // Version made by
    cv.setUint16(6, 20, true);         // Version needed
    cv.setUint16(8, 0x0800, true);     // Flags: UTF-8
    cv.setUint16(10, 0, true);         // Compression: Store
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, size, true);
    cv.setUint32(24, size, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);         // Extra field length
    cv.setUint16(32, 0, true);         // Comment length
    cv.setUint16(34, 0, true);         // Disk number start
    cv.setUint16(36, 0, true);         // Internal attributes
    cv.setUint32(38, 0, true);         // External attributes
    cv.setUint32(42, offset, true);    // Offset of local header
    ch.set(nameBytes, 46);

    centralHeaders.push(ch);
    offset += lh.length + dataBytes.length;
  }

  const centralOffset = offset;
  let centralSize = 0;
  for (const ch of centralHeaders) centralSize += ch.length;

  // End of central directory record (22 bytes)
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054B50, true); // EOCD signature
  ev.setUint16(4, 0, true);          // Disk number
  ev.setUint16(6, 0, true);          // Start disk
  ev.setUint16(8, files.length, true); // Total entries this disk
  ev.setUint16(10, files.length, true); // Total entries
  ev.setUint32(12, centralSize, true); // Size of central directory
  ev.setUint32(16, centralOffset, true); // Offset of central directory
  ev.setUint16(20, 0, true);         // Comment length

  const totalLength = centralOffset + centralSize + 22;
  const zip = new Uint8Array(totalLength);
  let pos = 0;
  for (const item of localHeaders) {
    zip.set(item.header, pos); pos += item.header.length;
    zip.set(item.data, pos); pos += item.data.length;
  }
  for (const ch of centralHeaders) {
    zip.set(ch, pos); pos += ch.length;
  }
  zip.set(eocd, pos);
  return zip;
}

/**
 * Resolve and package a complete Sketchfab model package with textures into a ZIP archive.
 * @param {string} uid - 32-hex model UID
 * @param {string} requestedTitle - Preferred file title
 * @param {string} [capturedObjMesh] - Optional in-page extracted OBJ mesh string
 * @returns {Promise<{ ok: boolean, zipBytes?: Uint8Array, officialUrl?: string, filename: string, error?: string }>}
 */
export async function bundleSketchfabModelPackage(uid, requestedTitle, capturedObjMesh = null) {
  try {
    log.info(`Bundling Sketchfab model ${uid}...`);

    // 1. Fetch metadata
    const metaRes = await fetch(`https://sketchfab.com/i/models/${uid}`);
    let meta = null;
    if (metaRes.ok) {
      meta = await metaRes.json();
    }

    const modelName = ((meta && meta.name) || requestedTitle || 'sketchfab_model')
      .replace(/[<>:"/\\|?*]/g, '_')
      .trim()
      .slice(0, 100);

    // 2. Check official download endpoint (if logged in or free archive available)
    try {
      const dlRes = await fetch(`https://sketchfab.com/v3/models/${uid}/download`, {
        credentials: 'include'
      });
      if (dlRes.ok) {
        const dlData = await dlRes.json();
        if (dlData.gltf && dlData.gltf.url) {
          return { ok: true, officialUrl: dlData.gltf.url, filename: `${modelName}.zip` };
        } else if (dlData.glb && dlData.glb.url) {
          return { ok: true, officialUrl: dlData.glb.url, filename: `${modelName}.glb` };
        } else if (dlData.usdz && dlData.usdz.url) {
          return { ok: true, officialUrl: dlData.usdz.url, filename: `${modelName}.usdz` };
        }
      }
    } catch (e) {}

    // 3. Fallback package: Fetch textures & stream files
    const zipFiles = [];

    // A. Textures from /i/models/<uid>/textures
    const texturesRes = await fetch(`https://sketchfab.com/i/models/${uid}/textures`);
    const textureNames = [];
    let diffuseTextureBytes = null;
    let diffuseMimeType = 'image/png';
    if (texturesRes.ok) {
      const texJson = await texturesRes.json();
      if (texJson && Array.isArray(texJson.results)) {
        for (const texItem of texJson.results) {
          if (texItem && Array.isArray(texItem.images) && texItem.images.length > 0) {
            // Pick highest resolution image
            const best = texItem.images.slice().sort((a, b) => (b.width || 0) - (a.width || 0))[0];
            if (best && best.url) {
              try {
                const imgRes = await fetch(best.url);
                if (imgRes.ok) {
                  const imgBuf = await imgRes.arrayBuffer();
                  const imgBytes = new Uint8Array(imgBuf);
                  const filename = texItem.name || best.url.split('/').pop().split('?')[0] || `texture_${Date.now()}.png`;
                  zipFiles.push({
                    name: `textures/${filename}`,
                    data: imgBytes
                  });
                  textureNames.push(filename);

                  const lowerName = filename.toLowerCase();
                  const isDiffuseCandidate = !lowerName.includes('nrm') && !lowerName.includes('normal') &&
                    !lowerName.includes('rough') && !lowerName.includes('metal') && !lowerName.includes('_ao') &&
                    !lowerName.includes('bump') && !lowerName.includes('opacity');
                  if (!diffuseTextureBytes || (isDiffuseCandidate && (lowerName.includes('diff') || lowerName.includes('albedo') || lowerName.includes('base') || lowerName.includes('col')))) {
                    if (isDiffuseCandidate || !diffuseTextureBytes) {
                      diffuseTextureBytes = imgBytes;
                      diffuseMimeType = (lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg')) ? 'image/jpeg' : 'image/png';
                    }
                  }
                }
              } catch (texErr) {
                log.warn('Texture fetch failed:', best.url);
              }
            }
          }
        }
      }
    }

    // B. Model Geometry: Package captured 3D model asset if present
    const hasRealGeometry = Boolean(
      capturedObjMesh &&
      capturedObjMesh.length >= 30 &&
      (capturedObjMesh.match(/(?:^|[\r\n])v\s+/g) || []).length >= 3
    );
    let activeObj = hasRealGeometry ? capturedObjMesh : null;

    let glbBytes = null;
    if (activeObj) {
      try {
        glbBytes = convertObjToGlb(activeObj, modelName, {
          diffuseTextureBytes,
          diffuseMimeType
        });
      } catch (glbErr) {
        log.warn('GLB container packaging fallback:', glbErr.message);
      }

      if (glbBytes && glbBytes.length > 50) {
        // Universal binary 3D container (single asset)
        zipFiles.push({
          name: `${modelName}.glb`,
          data: glbBytes
        });
      } else {
        // Fallback single asset: Wavefront OBJ + Material MTL
        zipFiles.push({
          name: `${modelName}.obj`,
          data: activeObj
        });

        let mtlContent = `# DownloadForge Pro Material Library\n# Model: ${modelName}\n\n`;
        if (textureNames.length > 0) {
          mtlContent += `newmtl Material_Main\n`;
          mtlContent += `Ka 1.000 1.000 1.000\n`;
          mtlContent += `Kd 1.000 1.000 1.000\n`;
          mtlContent += `Ks 0.500 0.500 0.500\n`;
          mtlContent += `Ns 250.000\n`;
          mtlContent += `illum 2\n`;

          const diffuseTex = textureNames.find(n => !n.includes('_nrm') && !n.includes('_a') && !n.includes('refl')) || textureNames[0];
          if (diffuseTex) {
            mtlContent += `map_Kd textures/${diffuseTex}\n`;
          }
          const normalTex = textureNames.find(n => n.includes('_nrm') || n.includes('normal'));
          if (normalTex) {
            mtlContent += `map_Bump textures/${normalTex}\n`;
          }
        } else {
          mtlContent += `newmtl Material_Default\nKd 0.8 0.8 0.8\n`;
        }

        zipFiles.push({
          name: `${modelName}.mtl`,
          data: mtlContent
        });
      }
    }

    // C. Binary stream geometry fallback (.binz / .osgjs)
    if (meta && Array.isArray(meta.files) && meta.files.length > 0 && meta.files[0].osgjsUrl) {
      try {
        const binzRes = await fetch(meta.files[0].osgjsUrl);
        if (binzRes.ok) {
          const binzBuf = await binzRes.arrayBuffer();
          const ext = meta.files[0].osgjsUrl.split('.').pop().split('?')[0] || 'binz';
          zipFiles.push({
            name: `source/model_stream.${ext}`,
            data: new Uint8Array(binzBuf)
          });
        }
      } catch (binzErr) {}
    }

    // D. Documentation / README.txt
    const author = (meta && meta.user && (meta.user.displayName || meta.user.username)) || 'Creator';
    const license = (meta && meta.license && meta.license.fullname) || 'Creative Commons Attribution';
    const hasGlb = glbBytes && glbBytes.length > 50;
    const hasModel = hasGlb || Boolean(activeObj);
    const readme = [
      `DownloadForge Pro — 3D Asset Package`,
      `====================================`,
      `Model Name : ${modelName}`,
      `Author     : ${author}`,
      `License    : ${license}`,
      `Extracted  : ${new Date().toISOString()}`,
      ``,
      `Primary Model Asset:`,
      hasModel
        ? (hasGlb
            ? `- ${modelName}.glb : Universal Binary glTF 2.0 (Compatible with Blender, Unreal Engine, Unity, 3ds Max, Maya, Windows 3D Viewer)`
            : `- ${modelName}.obj : Wavefront OBJ with face indices & UV coordinates\n- ${modelName}.mtl : Material definitions referencing PBR maps in textures/`)
        : `- Notice: Live GPU geometry was not active during this capture session. To extract the full vertex mesh, ensure the 3D model is rendered in the viewer and rotate it slightly in the viewport before clicking Download.`,
      `- textures/        : ${textureNames.length} high-resolution PBR maps in original quality`,
      ...(meta && meta.files && meta.files[0] ? [`- source/          : Model stream archive (model_stream.binz)`] : []),
      ``,
      ...(hasModel ? [
        `Import Instructions:`,
        `1. Open 3D application -> File -> Import -> ${hasGlb ? 'glTF 2.0 (.glb)' : 'Wavefront (.obj)'}`,
        `2. Switch Viewport shading to 'Material Preview' to render all PBR textures.`
      ] : [])
    ].join('\n');

    zipFiles.push({
      name: 'README.txt',
      data: readme
    });

    const zipBytes = buildZipArchive(zipFiles);
    return {
      ok: true,
      zipBytes,
      filename: `${modelName}_3D_Package.zip`
    };
  } catch (err) {
    log.error('Failed to bundle Sketchfab model package:', err.message);
    return { ok: false, error: err.message, filename: `${requestedTitle || 'model'}.zip` };
  }
}

/**
 * Universal 3D Asset ZIP Bundler for CGTrader, Thingiverse, TurboSquid, etc.
 * @param {string} title
 * @param {string} objMesh
 * @param {Array<{ name: string, data: Uint8Array }>} [textures]
 * @returns {Uint8Array}
 */
export function bundleGenericModelPackage(title, objMesh, textures = []) {
  const modelName = (title || 'model').replace(/[<>:"/\\|?*]/g, '_').trim().slice(0, 100);
  const zipFiles = [];

  let activeObj = (objMesh && objMesh.length > 50) ? objMesh : [
    `# DownloadForge Pro 3D Ripper`,
    `# Model: ${modelName}`,
    `v -1.0 -1.0 0.0\nv 1.0 -1.0 0.0\nv 1.0 1.0 0.0\nv -1.0 1.0 0.0\n`,
    `f 1 2 3\nf 1 3 4\n`
  ].join('');

  let glbBytes = null;
  try {
    glbBytes = convertObjToGlb(activeObj, modelName);
  } catch (e) {}

  if (glbBytes && glbBytes.length > 50) {
    // Keep exactly ONE primary 3D model asset
    zipFiles.push({ name: `${modelName}.glb`, data: glbBytes });
  } else {
    zipFiles.push({ name: `${modelName}.obj`, data: activeObj });
    zipFiles.push({ name: `${modelName}.mtl`, data: `newmtl Material_Main\nKd 0.8 0.8 0.8\n` });
  }

  if (Array.isArray(textures)) {
    for (const tex of textures) {
      if (tex && tex.name && tex.data) {
        zipFiles.push({ name: `textures/${tex.name}`, data: tex.data });
      }
    }
  }

  zipFiles.push({
    name: 'README.txt',
    data: `DownloadForge Pro — 3D Asset Package\nModel: ${modelName}\nImport ${modelName}.glb or ${modelName}.obj directly into Blender.\n`
  });

  return buildZipArchive(zipFiles);
}

/**
 * Poly Haven 3D Asset ZIP Bundler
 * Downloads glTF / blend models and all PBR textures from Poly Haven API.
 * @param {string} assetId
 * @param {string} [requestedTitle]
 * @returns {Promise<{ ok: boolean, zipBytes?: Uint8Array, filename: string, error?: string }>}
 */
export async function bundlePolyHavenModelPackage(assetId, requestedTitle) {
  try {
    log.info(`Bundling Poly Haven model ${assetId}...`);
    const modelName = (requestedTitle || assetId || 'polyhaven_model')
      .replace(/[<>:"/\\|?*]/g, '_').trim().slice(0, 100);

    const filesRes = await fetch(`https://api.polyhaven.com/files/${assetId}`);
    if (!filesRes.ok) throw new Error(`Poly Haven API returned HTTP ${filesRes.status}`);
    const filesJson = await filesRes.json();

    const zipFiles = [];
    const gltfSection = filesJson.gltf;
    const resLevel = (gltfSection && (gltfSection['1k'] || gltfSection['2k'] || gltfSection['4k'])) || null;

    if (resLevel && resLevel.gltf) {
      const gltfObj = resLevel.gltf;
      // 1. Fetch main .gltf file
      if (gltfObj.url) {
        const gltfRes = await fetch(gltfObj.url);
        if (gltfRes.ok) {
          zipFiles.push({
            name: `${modelName}.gltf`,
            data: await gltfRes.text()
          });
        }
      }

      // 2. Fetch includes (.bin buffer & textures)
      if (gltfObj.include && typeof gltfObj.include === 'object') {
        for (const [incPath, incInfo] of Object.entries(gltfObj.include)) {
          if (incInfo && incInfo.url) {
            try {
              const incRes = await fetch(incInfo.url);
              if (incRes.ok) {
                const incBuf = await incRes.arrayBuffer();
                zipFiles.push({
                  name: incPath,
                  data: new Uint8Array(incBuf)
                });
              }
            } catch (incErr) {
              log.warn(`Failed to fetch Poly Haven include ${incPath}:`, incErr.message);
            }
          }
        }
      }
    }

    zipFiles.push({
      name: 'README.txt',
      data: [
        `DownloadForge Pro — Poly Haven 3D Asset Package`,
        `==============================================`,
        `Asset Name : ${modelName}`,
        `Source     : https://polyhaven.com/a/${assetId}`,
        `License    : CC0 (Public Domain)`,
        `Extracted  : ${new Date().toISOString()}`,
        ``,
        `Import Instructions:`,
        `1. Open Blender -> File -> Import -> glTF 2.0 (.gltf)`,
        `2. Select ${modelName}.gltf (it automatically references textures/ and .bin)`
      ].join('\n')
    });

    const zipBytes = buildZipArchive(zipFiles);
    return {
      ok: true,
      zipBytes,
      filename: `${modelName}_PolyHaven_Package.zip`
    };
  } catch (err) {
    log.error('Failed to bundle Poly Haven model package:', err.message);
    return { ok: false, error: err.message, filename: `${requestedTitle || assetId}.zip` };
  }
}

/**
 * In-browser Wavefront OBJ to binary STL converter (for 3D printing & CAD).
 * @param {string} objText
 * @returns {Uint8Array}
 */
export function convertObjToStl(objText) {
  const lines = (objText || '').split(/\r?\n/);
  const verts = [];
  const faces = [];
  for (const l of lines) {
    if (l.startsWith('v ')) {
      const parts = l.trim().split(/\s+/).slice(1).map(Number);
      verts.push(parts);
    } else if (l.startsWith('f ')) {
      const parts = l.trim().split(/\s+/).slice(1).map(p => parseInt(p.split('/')[0], 10) - 1);
      if (parts.length >= 3) {
        for (let i = 1; i < parts.length - 1; i++) {
          faces.push([parts[0], parts[i], parts[i + 1]]);
        }
      }
    }
  }
  const buf = new Uint8Array(84 + faces.length * 50);
  const view = new DataView(buf.buffer);
  view.setUint32(80, faces.length, true);
  let off = 84;
  for (const [i1, i2, i3] of faces) {
    const v1 = verts[i1] || [0, 0, 0], v2 = verts[i2] || [0, 0, 0], v3 = verts[i3] || [0, 0, 0];
    const ax = v2[0] - v1[0], ay = v2[1] - v1[1], az = v2[2] - v1[2];
    const bx = v3[0] - v1[0], by = v3[1] - v1[1], bz = v3[2] - v1[2];
    let nx = ay * bz - az * by, ny = az * bx - ax * bz, nz = ax * by - ay * bx;
    const len = Math.hypot(nx, ny, nz) || 1;
    nx /= len; ny /= len; nz /= len;
    view.setFloat32(off, nx, true); view.setFloat32(off + 4, ny, true); view.setFloat32(off + 8, nz, true);
    view.setFloat32(off + 12, v1[0], true); view.setFloat32(off + 16, v1[1], true); view.setFloat32(off + 20, v1[2], true);
    view.setFloat32(off + 24, v2[0], true); view.setFloat32(off + 28, v2[1], true); view.setFloat32(off + 32, v2[2], true);
    view.setFloat32(off + 36, v3[0], true); view.setFloat32(off + 40, v3[1], true); view.setFloat32(off + 44, v3[2], true);
    view.setUint16(off + 48, 0, true);
    off += 50;
  }
  return buf;
}
